package fr.crozon.badminton;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Environment;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> chooser; static final int PICK=34;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);
 web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
 web.getSettings().setAllowFileAccess(true);web.addJavascriptInterface(new ExportBridge(),"AndroidExport");
 web.setWebViewClient(new WebViewClient());
 web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){chooser=cb;try{startActivityForResult(p.createIntent(),PICK);return true;}catch(Exception e){chooser=null;return false;}}});
 web.loadUrl("file:///android_asset/index.html"); }
 @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==PICK&&chooser!=null){chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,data));chooser=null;}}
 class ExportBridge { @JavascriptInterface public void saveFile(String content,String filename,String mime){
 try {String safe=filename.replaceAll("[^a-zA-Z0-9._-]","_");ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,safe);v.put(MediaStore.Downloads.MIME_TYPE,mime.split(";")[0]);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/TournoiCrozon");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Impossible de créer le fichier");try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(content.getBytes(StandardCharsets.UTF_8));}runOnUiThread(()->Toast.makeText(MainActivity.this,"Fichier enregistré dans Téléchargements/TournoiCrozon",Toast.LENGTH_LONG).show());
 }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Erreur export : "+e.getMessage(),Toast.LENGTH_LONG).show());}
 }}
 @Override public void onBackPressed(){web.evaluateJavascript("(function(){return !!document.querySelector('nav')})()",v->{web.goBack();});}
}
